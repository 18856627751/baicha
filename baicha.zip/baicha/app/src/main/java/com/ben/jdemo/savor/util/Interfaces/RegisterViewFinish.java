package com.ben.jdemo.savor.util.Interfaces;

/**
 * @author： BaiCha
 * @Time:2019/1/23
 * @description :注册界面注册完成的回调监听
 */
public interface RegisterViewFinish {
    void finishView();
}
