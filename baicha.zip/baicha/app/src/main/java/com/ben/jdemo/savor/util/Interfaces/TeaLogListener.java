package com.ben.jdemo.savor.util.Interfaces;

/**
 * @author： BaiCha
 * @Time:2019/1/18
 * @description :
 */
public interface TeaLogListener {
    void animProgress(boolean isFinish,float time);
}
